#ifndef SNAKE_H
#define SNAKE_H

int snake(void);

#endif /* SNAKE_H */
