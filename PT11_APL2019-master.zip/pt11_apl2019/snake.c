#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include <time.h>
#include <unistd.h>
#include "fichier.h" 	/*lié au fichier de score*/
#include "structures.h" /*lié aux structures du serpent*/

void AffichageGraphique(int,int);/*Affichage de la Fenetre*/

void AffichageGrille(int**,int,int,int,int,int,int,int);/*Affichage graphique de la grille de jeu*/

void InitialisationGrille(int**,int,int,int,int,int);/*Initialisation des valeurs de la grille*/

void Pastilles(int,int**,int,int,int,int,int,int,int,int,int,int);/*Disposition des pastilles*/

void ImpressionGrille(int**,int,int,int,int);/*Impression sur console pour vérification*/

int QuelleTouche(int,int,int,int,int,int); /*Quelle touche a été appuyée et comment l'interpreter*/

void Pause(int,int);/*Pauser le jeu*/

void CompterScore(int);/*Score du jeu*/

int snake(void)

{
	int FenetreX=600,FenetreY=500;
	AffichageGraphique(FenetreX,FenetreY);

/*------------------------- Les variables -------------------------*/

	/*Variables constantes représentant les dimensions du tableau*/
	/*On ajoute une marge pour l'affichage du score et du temps, d'où le 50 au lieu de 40*/
	int GLigne=50,GColonne=60;

	/*Variables nécéssaires au remplissage et affichage du tableau*/
	int PrintLigne,PrintColonne;

	/*La valeur des obtsacles et bordures*/
	int ValEchec=-1;

	/*Les valeurs des pastilles*/
	int ValPast=5;			/*Pastille Défault*/
	int ValPastSpe=10;		/*Pastille Spéciale*/
	int ValPastDouble=2;	/*Pastille qui double le score*/
	int ValPastEchec=-3;	/*Pastille Obstacle qui met le score à 0*/
	int ValPastSpeed=4;		/*Pastille Speed qui rend le score plus rapide*/
	int ValPastAjoute=0;	/*Valeur de la Pastille à ajouter*/

	/*------------------ Remplissage d'un écran blanc ------------------*/

	ChoisirEcran(1);				/*on choisi l'écran 1 */
	unsigned long couleur;
	couleur=CouleurParNom("white");
	EffacerEcran(couleur);			/*on y insère un fond blanc*/
	ChoisirEcran(0);				/*on retourne sur l'écran 0 où se passe le jeu*/


	/*------------------------ Gestion du Temps ------------------------*/

	#define CYCLE 1000000L	/*Cycle faisant 1s utilisé pour actualiser le chrono*/
	#define LAG 100000L		/*Cycle faisant 0.1s utilisé pour actualiser le snake*/

	char temps[500];	/*variable qui affichera le temps sous forme d'un tableau de caractères*/
	int secondes =0;	/*variable représentant les secondes*/
	unsigned long raffraichissement = 0;	/*permet l'actualisation du temps*/
	int minutes =0;		/*variable représentant les minutes*/
	unsigned long mise_a_jour =Microsecondes()+LAG;	/*mise à jour de l'algo*/
	unsigned long vitesse=0; /*La vitesse du serppent n'est pas affecté au début*/

	/*--------------------------- La grille ---------------------------*/

	/*1. Création dynamique Tableau à deux dimensions*/

	int** Grille=(int**)malloc(GLigne*sizeof(int*));
	for(PrintLigne=0;PrintLigne<GLigne;PrintLigne++)
	{
		Grille[PrintLigne]=(int*)malloc(GColonne*sizeof(int));
	}

	/*2. Remplissage de valeurs*/

	/*2.1 Obstacles*/
	InitialisationGrille(Grille,GLigne,GColonne,PrintLigne,PrintColonne,ValEchec);

	/*2.2 Pastilles*/
	srand(time(NULL));
	int NbrePast;
	for(NbrePast=5;NbrePast!=0;NbrePast--)
	{
		ValPastAjoute=ValPast;
		Pastilles(ValPastAjoute,Grille,GLigne,GColonne,minutes,secondes,ValPast,ValPastSpe,ValPastDouble,ValPastEchec,ValPastSpeed,ValEchec);
	}

	AffichageGrille(Grille,GLigne,GColonne,PrintLigne,PrintColonne,ValPast,ValPastSpe,ValEchec);

	/*----------------------- Algorithme du Snake -----------------------*/

	#define DROITE XK_Right
	#define GAUCHE XK_Left
	#define HAUT XK_Up
	#define BAS XK_Down
	#define ECHAP XK_Escape
	#define ESPACE XK_space
	#define POS_DEBUT 10 /*defini la position du seprent au lancement*/

	int touche=DROITE;	/*permet de savoir lorsqu'une touche est appuyée et dit au serpent que la premiere direction prise est DROITE*/
	int last_touche;		/*une touche tampon pour eviter que la touche "ESPACE" ne soit prise en compte comme un mouvement*/
	int direction =1;		/*direction du serpent au lancement du programme*/
	int taille_serpent=10;	/*taille initiale du serpent*/
	int poubelle;

	int score=0;	/*initialisation du score à 0 lors du lancement du programme*/
	CompterScore(score);

	int fin=0; /* permet de stopper le programme */


	/* --------------------- Appel des Structures --------------------- */

	TeteSerpent tete;
	tete.Serpent_direction=1;	/*direction initiale de la tete*/
	tete.tete_X=POS_DEBUT; 		/*la tete commence aux coordonnées [10][10]*/
	tete.tete_Y=POS_DEBUT;

	QueueSerpent Queue; 		/*la queue commence aux même coordonnées que la tete*/
	Queue.queue_X=POS_DEBUT;
	Queue.queue_Y=POS_DEBUT;


	while (fin==0)/*Tant que le jeu n'est pas fini ou interrompu*/
	{
		/*------------------------ Affichage du temps ------------------------*/

		if(Microsecondes() > raffraichissement)
		{
			raffraichissement = Microsecondes()+CYCLE;
			secondes ++;

			if (secondes == 60)
			{
				/*si 60s alors 1min*/
				minutes++;
				secondes = 0;
			}
			sprintf(temps, " Temps : %4d min %4d s",minutes,secondes);/*On affiche le temps*/
			CopierZone(1,0,200,200,200,30,95,420);/* on copie une zone vide pour reecrire le temps par dessus l'ancien temps*/
			ChoisirCouleurDessin(CouleurParNom("black"));
			EcrireTexte(100,440,temps,1);

			/*------------------------ Les Pastilles liées au temps ------------------------*/

			if(secondes%20==0)/*Toutes les 20 secondes une pastilles spéciale apparait*/
			{
				ValPastAjoute=ValPastSpe;
				Pastilles(ValPastAjoute,Grille,GLigne,GColonne,minutes,secondes,ValPast,ValPastSpe,ValPastDouble,ValPastEchec,ValPastSpeed,ValEchec);
			}

			if(secondes%30==0)/*Toutes les 30 secondes une pastille obstacle apparait*/
			{
				ValPastAjoute=ValPastEchec;
				Pastilles(ValPastAjoute,Grille,GLigne,GColonne,minutes,secondes,ValPast,ValPastSpe,ValPastDouble,ValPastEchec,ValPastSpeed,ValEchec);
			}

			if(minutes%1==0 & secondes==0)/*Toutes les minutes une pastille double apparait*/
			{
				ValPastAjoute=ValPastDouble;
				Pastilles(ValPastAjoute,Grille,GLigne,GColonne,minutes,secondes,ValPast,ValPastSpe,ValPastDouble,ValPastEchec,ValPastSpeed,ValEchec);
			}

			if(minutes%1==0 && secondes==30)/*Toutes les 1 minute et 30 secondes une pastille speed apparait*/
			{
				ValPastAjoute=ValPastSpeed;
				Pastilles(ValPastAjoute,Grille,GLigne,GColonne,minutes,secondes,ValPast,ValPastSpe,ValPastDouble,ValPastEchec,ValPastSpeed,ValEchec);
			}


		}/*End if*/

		if(Microsecondes()>mise_a_jour)
		{
			/*actualisation du snake*/
			mise_a_jour=Microsecondes()+LAG-vitesse;

			/*--------- Gestion des déplacements de la Queue du Serpent ---------*/

			if(taille_serpent !=0) /*On crée un décompte au lancement du programme pour laisser le temps au serpent d'initialiser la longueur de celui-ci*/
			{
				taille_serpent --; /*tant que la bonne longueur n'a pas été imprimée, on continue d'attendre en décrementant la longueur restante à afficher*/
			}

			if(taille_serpent <=0) /*une fois la bonne longueur affichée, on recupère la direction qu'à prise la dernière case en partant de la fin*/
			{
				/*cette dernière case est appellée Queue, on la trouve a la positions [Queue.queue_X][Queue.queue_Y] */
				if (Grille[Queue.queue_X][Queue.queue_Y] == DROITE)/*si la case, vérifiée par la Queue, indique que le serpent à tourné à droite*/
				{
					Queue.queue_Y ++; /*alors on change les coordonnées de la Queue en la deplaçant aussi à droite*/
					Grille[Queue.queue_X][Queue.queue_Y-1]=0; /*Une fois la queue déplacée, l'ancienne position est déclarée vide (libre)*/
				}

				else if (Grille[Queue.queue_X][Queue.queue_Y] == BAS) /* même principe pour un déplacement  vers le bas*/
				{
					Queue.queue_X ++;
					Grille[Queue.queue_X-1][Queue.queue_Y]=0;
				}

				else if (Grille[Queue.queue_X][Queue.queue_Y] == HAUT) /* même principe pour un déplacement  vers le haut*/
				{
					Queue.queue_X --;
					Grille[Queue.queue_X+1][Queue.queue_Y]=0;
				}

				else if (Grille[Queue.queue_X][Queue.queue_Y] == GAUCHE) /* même principe pour un déplacement à gauche*/
				{
					Queue.queue_Y --;
					Grille[Queue.queue_X][Queue.queue_Y+1]=0;
				}

				ChoisirCouleurDessin(CouleurParNom("white"));
				RemplirRectangle(Queue.queue_Y*10,Queue.queue_X*10,10,10); /*L'ancienne position déclarée vide est peinte en blanc*/
			}

			/*--- Gestion des déplacements du Serpent lorsqu'aucune touche n'est pas appuyée ---*/

			if (tete.Serpent_direction ==1 ) /* déplacement à droite */
			{
				Grille[tete.tete_X][tete.tete_Y] = DROITE; /* On place la valeur de la touche appuyée aux coordonnées correspondantes à la tete du Serpent*/
				tete.tete_Y ++;

			}

			if (tete.Serpent_direction ==2) /* déplacement vers le bas */
			{
				Grille[tete.tete_X][tete.tete_Y] = BAS;
				tete.tete_X ++;

			}

			if (tete.Serpent_direction ==3) /* déplacement vers le haut */
			{
				Grille[tete.tete_X][tete.tete_Y] = HAUT;
				tete.tete_X --;
			}

			if (tete.Serpent_direction ==4) /* déplacement à gauche */
			{
				Grille[tete.tete_X][tete.tete_Y] = GAUCHE;
				tete.tete_Y --;

			}

			ChoisirCouleurDessin(CouleurParNom("black"));
			RemplirRectangle(tete.tete_Y*10,tete.tete_X*10,10,10); /* on récupére la position de la tete du Serpent sur la grille et on l'affiche*/

			/*----------------------- Gestions des Touches -----------------------*/

			if(ToucheEnAttente())
			{
				last_touche = Touche(); /*on récupere la touche qui a été appuyée,la valeur est placée dans une touche tampon*/
				if (last_touche == ECHAP)/*si on appuie sur Esc alors on quitte le jeu*/
				{
					fin=1;
				}

				touche = QuelleTouche(last_touche,touche,fin,FenetreX,FenetreY,poubelle);

	/*droite*/	if(touche == DROITE && tete.Serpent_direction != 4 && tete.Serpent_direction != 1)
				{
					/*On donne au serpent la direction droite, s'il ne va pas déjà à droite ou s'il ne veut pas non plus aller en contre sens*/
					tete.Serpent_direction = 1;
				}

				/*Même principe pour les autres touches*/
	/*bas*/		if (touche == BAS && tete.Serpent_direction != 3 && tete.Serpent_direction != 2)
				{
					tete.Serpent_direction = 2;
				}
	/*haut*/	if (touche == HAUT && tete.Serpent_direction != 2 && tete.Serpent_direction != 3)
		   		{
					tete.Serpent_direction = 3;
				}
	/*gauche*/	if (touche ==  GAUCHE && tete.Serpent_direction != 1 && tete.Serpent_direction != 4)
				{
					tete.Serpent_direction = 4;
				}

			}/*End ToucheEnAttente*/

			/*----------------- Le serpent et son environnement -----------------*/

			/*Le serpent touche une bordure ou se marche dessus*/
			/*(le serpent est représenté dans la grille par un nombre plus grand que les pastilles)*/
			if (Grille[tete.tete_X][tete.tete_Y]==ValEchec | Grille[tete.tete_X][tete.tete_Y] > ValPastSpe)
			{
				fin=1;
			}

			/*Le serpent mange une pastille normale*/
			if (Grille[tete.tete_X][tete.tete_Y]==ValPast)
			{
				/*On augmente le score*/
				score = score + ValPast;
				/*On aggrandit la taille du serpent*/
				taille_serpent = taille_serpent +4;/*on augmente de 2 segments (1 segment = 2 unités)*/
				/*On actualise les points*/
				CompterScore(score);
				/*On rajoute une pastille*/
				ValPastAjoute=ValPast;
				Pastilles(ValPastAjoute,Grille,GLigne,GColonne,minutes,secondes,ValPast,ValPastSpe,ValPastDouble,ValPastEchec,ValPastSpeed,ValEchec);
			}

			/*Le serpent mange une pastille spéciale*/
			if (Grille[tete.tete_X][tete.tete_Y]==ValPastSpe)
			{
				score = score + ValPastSpe;
				taille_serpent = taille_serpent +6;
				CompterScore(score);
				/*La pastille ne réapparait pas avant 30 secondes*/
			}

			/*Le serpent mange une pastille double*/
			if (Grille[tete.tete_X][tete.tete_Y]==ValPastDouble)
			{
				score = score * ValPastDouble;
				taille_serpent = taille_serpent +8;
				CompterScore(score);
				/*La pastille ne réapparait pas avant 1 minute*/
			}

			/*Le serpent mange une pastille speed*/
			if (Grille[tete.tete_X][tete.tete_Y]==ValPastEchec)
			{
				score = 0;
				/*La taille ne change pas*/
				CompterScore(score);
				/*La pastille ne réapparait pas avant 30 secondes*/
			}

			/*Le serpent mange une pastille speed*/
			if (Grille[tete.tete_X][tete.tete_Y]==ValPastSpeed)
			{
				/*Le score en change pas*/
				/*La taille ne change pas*/
				vitesse=vitesse+10000L;
				/*La pastille ne réapparait pas avant 1 minute et 30 secondes*/
			}

		}/*End mise à jour lag*/

	}/*End While*/

	char scorefin[500];

	ChargerImageFond("./image/snakuEnd.png");
	/* charge une image qui remplit le fond de la fenêtre */
	sprintf(temps, " Temps :%4dmin%4ds",minutes,secondes);/*On affiche le temps final*/
	ChoisirCouleurDessin(CouleurParNom("black"));
	EcrireTexte(50,300,temps,2);

	sprintf(scorefin,"Score : %d",score);/*on affiche le score final*/
	ChoisirCouleurDessin(CouleurParNom("black"));
	EcrireTexte(400,300,scorefin,2);

	if (SourisCliquee()){} /*tampon au cas ou l'utilisateur a cliqué durant le jeu, pour permettre d'afficher le game over*/
	while(1)/*Boucle infini pour afficher l'image game over*/
	{
	if(SourisCliquee()) break; /*on retourne au menu si l'utilisateur clique ou appuie sur une touche*/
	}

	FermerGraphique();
	free(Grille);/*on libère la place allouée par le malloc*/
	fichier(score,1); /*On appelle fichier en lui transmettant le score ainsi que le mode écriture*/
	return EXIT_SUCCESS;
}

/*--------------------------------------------------------- Les Fonctions ---------------------------------------------------------*/

/*Affichage de la Fenetre*/
void AffichageGraphique(int FenetreX,int FenetreY)
{
	/*La Fenetre*/
	InitialiserGraphique();
	int EcranX,EcranY;
	EcranX=(Maxx()/2)-(FenetreX);/*milieu axe X*/
	EcranY=(Maxy()/2)-(FenetreY);/*milieu axe Y*/
	CreerFenetre(EcranX,EcranY,FenetreX,FenetreY);
	ChoisirTitreFenetre("THE INCREDIBLE SNAKE");/*Titre*/
	ChoisirCurseur(3);/*Curseur*/
	ChargerImageFond("snaku.png");/*Fond*/
}

/*Affichage de la Grille pour la partie*/
void AffichageGrille(int** Grille,int GLigne,int GColonne,int PrintLigne,int PrintColonne,int ValPast,int ValPastSpe,int ValEchec)
{
	for(PrintLigne=0;PrintLigne<GLigne;PrintLigne++)
	{
		for(PrintColonne=0;PrintColonne<GColonne;PrintColonne++)
		{
			if(Grille[PrintLigne][PrintColonne]==0)
			{
				ChoisirCouleurDessin(CouleurParNom("white"));
				RemplirRectangle(PrintColonne*10,PrintLigne*10,10,10);
			}
			if(Grille[PrintLigne][PrintColonne]==ValEchec)
			{
				ChoisirCouleurDessin(CouleurParNom("grey"));
				RemplirRectangle(PrintColonne*10,PrintLigne*10,10,10);
			}
			if(Grille[PrintLigne][PrintColonne]==ValPast)
			{
				ChoisirCouleurDessin(CouleurParNom("red"));
				RemplirRectangle(PrintColonne*10,PrintLigne*10,10,10);
			}
		}
	}/*Fin du for*/
}

/*Remplissage Grille (valeur neutre et erreur)*/
void InitialisationGrille(int** Grille,int GLigne,int GColonne,int PrintLigne,int PrintColonne,int ValEchec)
{
	/*1. On remplit le tableau de valeur neutre 0*/
	for(PrintLigne=0;PrintLigne<GLigne;PrintLigne++)
	{
		for(PrintColonne=0;PrintColonne<GColonne;PrintColonne++)
		{
			Grille[PrintLigne][PrintColonne]=0;
		}
	}

	/*2. On spécifie les bordures qui ont une valeur d'échec -1*/
	for(PrintColonne=0;PrintColonne<GColonne;PrintColonne++)
	{
		Grille[0][PrintColonne]=ValEchec;
		Grille[GLigne-11][PrintColonne]=ValEchec;
	}
	for(PrintLigne=0;PrintLigne<GLigne;PrintLigne++)
	{
		Grille[PrintLigne][0]=ValEchec;
		Grille[PrintLigne][GColonne-1]=ValEchec;
	}

	/*3. On ajoute la marge*/
	for(PrintLigne=GLigne-11;PrintLigne<GLigne;PrintLigne++)
	{
		for(PrintColonne=0;PrintColonne<GColonne;PrintColonne++)
		{
			Grille[PrintLigne][PrintColonne]=-1;
		}
	}

}

/*Remplissage Grille (valeur pastille)*/
void Pastilles(int ValPastAjoute,int** Grille,int GLigne,int GColonne,int minutes,int secondes,int ValPast,int ValPastSpe,int ValPastDouble,int ValPastEchec,int ValPastSpeed,int ValEchec)
{
	/*1. Generer positions aléatoires*/
	int PastLigne=(rand()%GLigne);
	int PastColonne=(rand()%GColonne);

	/*2. Eviter une position avec une pastille, une bordure ou le serpent*/
	while(Grille[PastLigne][PastColonne]!=0)	/*Tant que l'emplacement n'est pas neutre (-1,5,10,20 ou >20 pour le serpent)*/
	{
		PastLigne=(rand()%GLigne);				/*On réactualise les positions*/
		PastColonne=(rand()%GColonne);
	}
	/*3. Placer la Pastilles*/

	Grille[PastLigne][PastColonne]=ValPastAjoute;

	/*4. Vérifier le type de pastille qu'on veut*/

	if(ValPastAjoute==ValPast)
	{
		ChoisirCouleurDessin(CouleurParNom("red"));
		RemplirRectangle(PastColonne*10,PastLigne*10,10,10);
	}

	if(ValPastAjoute==ValPastSpe)
	{
		ChoisirCouleurDessin(CouleurParNom("orange"));
		RemplirRectangle(PastColonne*10,PastLigne*10,10,10);
	}

	if(ValPastAjoute==ValPastDouble)
	{
		ChoisirCouleurDessin(CouleurParNom("green"));
		RemplirRectangle(PastColonne*10,PastLigne*10,10,10);
	}

	if(ValPastAjoute==ValPastEchec)
	{
		ChoisirCouleurDessin(CouleurParNom("grey"));
		RemplirRectangle(PastColonne*10,PastLigne*10,10,10);
	}

	if(ValPastAjoute==ValPastSpeed)
	{
		ChoisirCouleurDessin(CouleurParNom("purple"));
		RemplirRectangle(PastColonne*10,PastLigne*10,10,10);
	}
}

/*Impression Grille pour vérification*/
void ImpressionGrille(int** Grille,int GLigne,int GColonne,int PrintLigne,int PrintColonne)
{
	for(PrintLigne=0;PrintLigne<GLigne;PrintLigne++)
	{
		for(PrintColonne=0;PrintColonne<GColonne;PrintColonne++)
		{
			printf("%2d ",Grille[PrintLigne][PrintColonne]);
		}
		printf("\n");
	}
}

/*Mettre le jeu en pause*/
void Pause(int FenetreX,int FenetreY)
{

	int touche;
	int poubelle;

	ToucheEnAttente();
	touche = Touche();

	while (touche != ESPACE)
	{
		ToucheEnAttente();
		touche = Touche();
	}
}

/*même principe d'affichage que pour le score*/
void CompterScore(int Points)
{
	char ScoreJoueur[500];
	sprintf(ScoreJoueur,"Score : %d",Points);
	CopierZone(1,0,200,200,200,30,330,420); /*copier une zone vide pour reecrire le score par dessus l'ancien score*/
	ChoisirCouleurDessin(CouleurParNom("black"));
	EcrireTexte(350,440,ScoreJoueur,1);
}

int QuelleTouche(int last_touche,int touche,int fin,int FenetreX,int FenetreY,int poubelle)
{ /*fonction detectant la touche appuyée*/
/*si la touche ne correspond à aucune touche prévue alors on l'envoie dans une poubelle*/
	if (last_touche != ESPACE && last_touche != ECHAP && last_touche != DROITE && last_touche != BAS && last_touche != HAUT && last_touche != GAUCHE)
	{
		last_touche = poubelle;
	}
	/*si la touche est juste differente de la barre espace alors on prends le mouvement comme prévu*/
	if (last_touche != ESPACE)
	{
		touche = last_touche;
		return touche;
	}
	/*si la touche space est appuyé alors on met en pause le jeu*/
	if (last_touche == ESPACE)
	{
		Pause(FenetreX,FenetreY);/*appelle la fonction pause*/
	}
}
