#include<stdlib.h>
#include<stdio.h>
#include <graph.h>
#include <unistd.h>
#include "snake.h"
#include "main.h"
#define TAILLE_MAX 1000

void AffichageGraphique(int,int);/*Affichage de la Fenetre */

void classement(int scores[], int size); /*tri*/

int fichier(int nouveau_score, int mode)
{

/*------------------------ Lecture du fichier scores -----------------*/
  if(mode == 2)
  {
  FILE* fichier = NULL;
  char chaine[TAILLE_MAX] = "";
  int scores[100]={0};
  int i=0;
  int compte;
  fichier = fopen("scores.txt", "r");

    if (fichier != NULL)
    {
      while (fgets(chaine, TAILLE_MAX, fichier) != NULL) /* On lit le fichier tant qu'on ne reçoit pas d'erreur (NULL)*/
      {
          fscanf(fichier,"%d",&scores[i]);/*on récupére les données du fichier score.txt*/
          i++;
      }
      compte = i;

      fclose(fichier);
      classement(scores,compte);/*et on tri ces données avant de les afficher*/


      int FenetreX=600,FenetreY=500;
      AffichageGraphique(FenetreX,FenetreY);

      char ScoreJoueur[500];
      char retour[500];
      int rang=2;
      double augm=1;


      ChoisirCouleurDessin(CouleurParNom("lightgrey"));/*affichage du meilleur score*/
      RemplirRectangle(151,51,379,269);
      sprintf(ScoreJoueur,"Le record est : %d",scores[0]);
      ChoisirCouleurDessin(CouleurParNom("black"));
      EcrireTexte(180,70,ScoreJoueur,1);
      DessinerRectangle(150,50,380,270);

      for (i=1;i<5; i++,rang++)
      {
        augm = augm +0.5;/*décalage des rangs pour un affichage correct*/
        sprintf(ScoreJoueur,"Le %d eme meilleur score est : %d",rang,scores[i]);
        ChoisirCouleurDessin(CouleurParNom("black"));
        EcrireTexte(180,100*augm,ScoreJoueur,1);
      }

      sprintf(retour,"Retour au menu"); /*creation d'un bouton retour*/
      ChoisirCouleurDessin(CouleurParNom("grey"));
      RemplirRectangle(440,432,125,25);
      ChoisirCouleurDessin(CouleurParNom("black"));
      DessinerRectangle(440,432,125,25);
      EcrireTexte(450,450,retour,1);

      int fin=0;
      int x, y;
      SourisPosition();
      x = _X;
      y = _Y;
      while(fin==0)
      {
        if (SourisCliquee())/*si on clique sur le bouton de retour alors on retourne sur le menu*/
        {
          if ((_X >= 440) && (_X <= 565) && (_Y >= 432) && (_Y <= 457))
          {
            FermerGraphique();
            main();
            fin=1;
          }
        }
      }
    }
  }
/*-------------------------Ecriture dans le fichier scores----------------*/

  if (mode == 1)
  {

  FILE* fichier = NULL;
  fichier = fopen("./scores.txt", "r+");

    if (fichier != NULL)
    {
      fseek(fichier, 0, SEEK_END);  /*On va à la fin du fichier pour écrire le nouveau score fait*/
      fputc('\n',fichier);
      fprintf(fichier,"%d",nouveau_score);
    }
      fclose(fichier);
    	main();  /* on retourne sur le menu*/
      return EXIT_SUCCESS;
  }
}



/*----- FONCTIONS ----- */


void classement(int scores[], int size) /*tri à bulle décroissant*/
{
    int i = 0;
    int j = 0;
    int tmp = 0;
    for(i=0; i<size ; i++)
    {
        for(j=i; j<size; j++)
        {
            if(scores[j]>scores[i]){
                tmp = scores[i];
                scores[i] = scores[j];
                scores[j] = tmp;
            }
        }
    }
}
