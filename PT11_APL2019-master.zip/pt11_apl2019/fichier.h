#ifndef FICHIER_H
#define FICHIER_H

int fichier(int nouveau_score,int mode);

#endif /* FICHIER_H */
