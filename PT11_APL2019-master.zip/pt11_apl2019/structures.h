#ifndef STRUCTURES_H
#define STRUCTURES_H

typedef struct TeteSerpent TeteSerpent;
struct TeteSerpent {
  int Serpent_direction;
  int tete_X;
  int tete_Y;
};

typedef struct QueueSerpent QueueSerpent;
struct QueueSerpent {
  int queue_X;
  int queue_Y;
};

#endif /* STRUCTURES_H */