#ifndef MAIN_H
#define MAIN_H

int main(void);

#endif /* MAIN_H */
