#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "snake.h"
#include "fichier.h"

int main(void)
{

/*------------------------- Gestion erreur -------------------------*/

	int Erreur;
	/*
		A chaque fois qu'on appelle une fonction qui retourne un résultat (1 ou 0),
		on vérifie si elle a marché. Si le résultat vaut 0, on affiche une phrase
		indiquant la source d'erreur.
	*/

/*------------------------ Afficher le menu ------------------------*/


	Erreur=InitialiserGraphique();

	if(Erreur==0){printf("Erreur avec l'Initialision Graphique\n");}

	/*1. La Fenetre*/
	int EcranX,EcranY;
	int FenetreY=500,FenetreX=600;	/*Dimensions de la fenêtre*/
	EcranX=(Maxx()/2)-(FenetreX);	/*milieu axe X*/
	EcranY=(Maxy()/2)-(FenetreY);	/*milieu axe Y*/
	Erreur=CreerFenetre(EcranX,EcranY,FenetreX,FenetreY);

	if(Erreur==0){printf("Erreur avec la Création de Fenetre");}

	ChoisirTitreFenetre("THE INCREDIBLE SNAKE");/*Titre*/
	ChoisirCurseur(58);/*Curseur*/
	ChargerImageFond("./image/snaku.png");/*Fond*/

	/*2. Les Boutons*/

	/*2.1. Les Dimensions*/
	int BoutonLongueur=150,BoutonLargeur=40;/*Dimensions des boutons*/
	int PositionBtnX;						/*Position des boutons sur l'axe X*/
	int JouerY,ReglesY,ScoreY,QuitterY;		/*Position des boutons sur l'axe Y*/
	int MarginTop=20;						/*Marge entre les boutons*/

	/*On centre le bouton selon sa longueur sur l'axe X*/
	PositionBtnX=(FenetreX/2)-(BoutonLongueur/2);

	/* --> On divise la fenetre en 4 pour les 4 boutons*/
	/* --> On retire la moitié de la largeur du bouton pour le centrer*/
	/* --> On ajoute une marge*/
	JouerY=(FenetreY/4)-(BoutonLargeur/2)+MarginTop;

	/* --> On ajoute 40 à chaque fois et la largeur du bouton pour décaler les boutons*/
	ReglesY=(FenetreY/4)-(BoutonLargeur/2)+MarginTop+BoutonLargeur+40;
	ScoreY=(FenetreY/4)-(BoutonLargeur/2)+2*BoutonLargeur+80+MarginTop;
	QuitterY=(FenetreY/4)-(BoutonLargeur/2)+3*BoutonLargeur+120+MarginTop;

	/*2.2. Placement des boutons*/

	/*Jouer*/
	while(1)
	{
	Erreur=ChargerImage("./image/jouer.png",PositionBtnX,JouerY,0,0,BoutonLongueur,BoutonLargeur);
	if(Erreur==0){printf("Erreur avec le Chargement de l'image Jouer");}

	/*Regles*/
	Erreur=ChargerImage("./image/regles.png",PositionBtnX,ReglesY,0,0,BoutonLongueur,BoutonLargeur);
	if(Erreur==0){printf("Erreur avec le Chargement de l'image Regles");}

	/*Score*/
	Erreur=ChargerImage("./image/scores.png",PositionBtnX,ScoreY,0,0,BoutonLongueur,BoutonLargeur);
	if(Erreur==0){printf("Erreur avec le Chargement de l'image Score");}

	/*Quitter*/
	Erreur=ChargerImage("./image/quitter.png",PositionBtnX,QuitterY,0,0,BoutonLongueur,BoutonLargeur);
	if(Erreur==0){printf("Erreur avec le Chargement de l'image Quitter");}

/*--------------------- Interaction avec joueur ---------------------*/


		/*Détecter le choix du joueur*/
		if(SourisCliquee())
			{
				/*Repérer la position de la souris cliquée*/
				SourisPosition();
				int SourisX=_X;
				int SourisY=_Y;
				/*La Position X de la Souris doit être comprise entre PositionBtnX et PositionBtnX + Longueur du bouton*/
				/*La Position Y de la Souris doit être comprise entre PositionBtnY et PositionBtnY + Largeur du bouton*/
				/*PositionBtnY varie selon le bouton, on a JouerY, ReglesY, ScoreY et QuitterY*/
/*Jouer*/		if(PositionBtnX<=SourisX & SourisX<=PositionBtnX+BoutonLongueur & JouerY<=SourisY & SourisY<=JouerY+BoutonLargeur)
				{
					/*Le jouer a cliqué sur Jouer, on lance le Snake*/
					FermerGraphique();
					snake();
				}
/*Regles*/		if(PositionBtnX<=SourisX & SourisX<=PositionBtnX+BoutonLongueur & ReglesY<=SourisY & SourisY<=ReglesY+BoutonLargeur)
				{
					ChargerImageFond("./image/menuRegles.png"); /*on affiche les regles*/
					while(1)
					{
						if (SourisCliquee())
						{
						break; /*si on clique alors on retourne sur l'affichage classique du menu*/
						}
					}
					ChargerImageFond("./image/snaku.png");/*Fond*/
				}
/*Score*/		if(PositionBtnX<=SourisX & SourisX<=PositionBtnX+BoutonLongueur & ScoreY<=SourisY & SourisY<=ScoreY+BoutonLargeur)
				{
					/*Le jouer a cliqué sur Score, on affiche le classement*/
					FermerGraphique();
					fichier(0,2); /*on ajoute un score tampon (0) et on lance l'affichage des scores*/
				}
/*Quitter*/		if(PositionBtnX<=SourisX & SourisX<=PositionBtnX+BoutonLongueur & QuitterY<=SourisY & SourisY<=QuitterY+BoutonLargeur)
				{
					/*Le jouer a cliqué sur Quitter, on quitte le jeu*/
					FermerGraphique();
					return EXIT_SUCCESS;
				}
			}
	}
}
