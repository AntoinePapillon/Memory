/**
 * La classe <code>Fenetre</code> est utilise pour afficher les fenetres qui se succedent
 * jusqu'a mener a l'algorithme
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Fenetre extends JFrame {
	private boolean alea;
	private int moyenne;
	private int dimension = 0;
	private int[][] cases = null;

	private JPanel panel = new JPanel();
	private JPanel panel2 = new JPanel();
	private JPanel panel3 = new JPanel();
	private JButton button = new JButton();
	private JLabel label = new JLabel("Quel dimension ?");
	private JButton button2 = new JButton("Preremplissage aleatoire");
	private JTextField zoneDeTexte = new JTextField("5");

	private Simulation s = new Simulation();
	private AutomateDetermine ad = new AutomateDetermine(s,this);
	private AutomateAleatoire aa = new AutomateAleatoire(s);
	private CentFoisAutomate cfa = new CentFoisAutomate(aa,ad);
	private ToucheEvent keyevent = new ToucheEvent(s);
	private SuperCoding sup = new SuperCoding();
	private Forme f = new Forme(this);
	private Event e = new Event(this,f,s,sup);
	private QuitListener ql = new QuitListener();
	private ButtonListener bl = new ButtonListener(this);

	/**
	 * La premiere fenetre, qui affiche deux options :
	 * - Creer un Labyrinthe
	 * - Selectionner un Labyrinthe deja existant
	 *
	 */
	public Fenetre(){

		super();
		this.setSize(400,300);
		this.setLocation(100,100);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		button.addActionListener(bl);
		button2.addActionListener(bl);

		button.setText("Creer un Labyrinthe");
		button2.setText("Selectionner un Labyrinthe deja existant");

		panel.add(button);
		panel.add(button2);
		this.add(panel);

	}
	/**
	 * La deuxieme fenetre on y arrive en choississant "Selectionner un Labyrinthe deja existant"
	 * dans la premiere fenetre. On y choisit le fichier a ouvrir contenant la sauvegarde
	 * d'un labyrinthe
	 *
	 */
	public void selection(){

		getContentPane().removeAll();
		getContentPane().revalidate();

		JFileChooser chooser = new JFileChooser();
	    int returnVal = chooser.showOpenDialog(this);
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
	       cases=sup.lecteur(chooser.getSelectedFile().getName());
	       dimension=sup.getDimension();
	    }

	    this.automate();

	}
	/**
	 * La troisieme fenetre,on y arrive en choississant "Creer un Labyrinthe"
	 * dans la premiere fenetre.
	 * On y renseigne la dimension du labyrinthe que l'on souhaite creer.
	 *
	 */
	public void taille(){
		getContentPane().removeAll();
		getContentPane().revalidate();

		panel.remove(button2);


		button.setText("OK");
		zoneDeTexte.setBackground(Color.LIGHT_GRAY);

		zoneDeTexte.setPreferredSize(new Dimension(250, 20));

		panel.add(label);
		panel2.add(zoneDeTexte);
		panel3.add(button);

		this.add(panel,BorderLayout.NORTH);
		this.add(panel2,BorderLayout.CENTER);
		this.add(panel3,BorderLayout.SOUTH);
	}

	/**
	 * La quatrieme fenetre,on y arrive en choississant "Creer un Labyrinthe"
	 * dans la premiere fenetre.
	 * On a le choix entre deux options :
	 * Labyrinthe vide : creera un labyrinthe vide de tout mur
	 * Labyrinthe Prerempli : creera un labyrinthe remplis aleatoirement de mur
	 */
	public void choixConstruction(){
		getContentPane().removeAll();
		getContentPane().revalidate();

		label.setText("Quel type de Labyrinthe souhaitez vous ?");
		button.setText("Labyrinthe vide");
		button2.setText("Labyrinthe Prerempli");


		panel.add(button);
		panel.add(button2);

		this.add(panel);

	}

	/**
	 * La cinquieme fenetre,on y arrive en choississant apres n'importe 
	 * quel option de la quatrieme fenetre
	 * 
	 * On voit s'afficher un labyrinthe modifiable selon nos choix
	 * On est informer de quelque instruction pour comprendre
	 * comment construire le labyrinthe
	 * @param b informe si le labyrinthe doit etre vide ou prerempli
	 */
	public void creation(boolean b){

		getContentPane().removeAll();

		dimension=Integer.parseInt(zoneDeTexte.getText().trim().replaceAll("\n", ""));
		this.setSize(1000,830);


		f.creationLab(dimension,b);
		f.repaint();



		this.add(f);

		JOptionPane.showMessageDialog(null, "Bonjour ! Voici les choses a savoir avant de construire son premier labyrinthe :\n-Chaque case a deux etat possible : bloque (noir) ou libre (blanche). Cliquer dessus la fait changer d'etat.\n-Ici thesee est le point de depart de l'automate qui essaiera de rejoindre le minotaure.\n-Cliquez sur thesee, puis cliquez sur une case pour l'y placer.\n-Cliquez sur le minotaure, puis cliquez sur une case pour l'y placer.\n-Si vous changez d'avis, cliquez sur l'un d'entre eux pour l'enlever de la case ou il se trouve et le replacer ailleurs.\n-Quand vous aurez fini, cliquez sur le bouton \"valider\"",
            "Informations pratiques", JOptionPane.PLAIN_MESSAGE);

		this.addMouseListener(e);
		this.addMouseMotionListener(e);

	}
	/**
	 * La sixieme fenetre, on y arrive après avoir quitté la cinquieme fenetre
	 *
	 * On a le choix entre sauvegarder ou non le labyrinthe
	 *
	 * @param cases tableau en deux dimension contenant le labyrinthe
	 */
	public void sauvegarde(int[][] cases){
		this.cases = cases;
		this.setSize(800,300);

		getContentPane().removeAll();
		getContentPane().revalidate();

		this.removeMouseListener(e);
		this.removeMouseMotionListener(e);

		label.setText("Souhaitez vous sauvegardez le labyrinthe sous la forme d'un fichier .lab ?");
		button.setText("Oui");
		button2.setText("Non");

		panel.add(button);
		panel.add(button2);

		this.add(panel);

	}
	/**
	 * La septieme fenetre, on y arrive après avoir choisit de sauvegarder
	 * dans la sixieme fenetre.
	 *
	 * On a le choix du nom de la sauvegarde
	 */
	public void nomSauvegarde(){
		getContentPane().removeAll();
		getContentPane().revalidate();
		panel.removeAll();
		panel.revalidate();

		panel.add(zoneDeTexte);
		panel.add(button);

		this.add(panel);

		button.setText("Valider");
		zoneDeTexte.setText("Saisissez le nom de la sauvegarde");
	}
	/**
	 * La huitieme fenetre, on y arrive après avoir choisit le nom de la sauvegarde
	 * dans la septieme fenetre.
	 *
	 * la methode lance la sauvegarde
	 */
	public void lancement(){
		sup.sauvegarde(dimension,cases,zoneDeTexte.getText());
		this.sauvegardeReussie();
	}
	/**
	 * La neuvieme fenetre renseigne que la sauvegarde s'est bien deroulee
	 *
	 */
	public void sauvegardeReussie(){
		getContentPane().removeAll();
		getContentPane().revalidate();


		panel.remove(zoneDeTexte);
		panel.remove(button2);
		panel.remove(button);

		label.setText("Sauvegarde Reussie");
		button.setText("Passez a la simulation");

		panel2.add(label);
		panel.add(button);

		this.add(panel2,BorderLayout.CENTER);
		this.add(panel,BorderLayout.SOUTH);

	}
	/**
	 * La dixieme fenetre donne le choix entre deux automates
	 *
	 */
	public void automate(){


		panel.removeAll();
		panel2.removeAll();
		panel2.revalidate();
		panel.revalidate();

		label.setText("Pour la simulation vous avez le choix entre deux modes d'automates de resolution :");
		button.setText("Automates Aleatoire");
		button2.setText("Automate Determine");

		panel2.add(label);
		panel.add(button);
		panel.add(button2);

		this.add(panel2,BorderLayout.NORTH);
		this.add(panel,BorderLayout.CENTER);

	}
	/**
	 * La onzieme fenetre donne le choix entre un affichage manuel ou un affichage de la moyenne
	 *
	 * @param alea vrai si l'automate aleatoire a ete choisit, faux sinon
	 */
	public void visionnage(boolean alea){


		panel.removeAll();
		panel2.removeAll();
		panel2.revalidate();
		panel.revalidate();

		this.alea = alea;

		label.setText("Tres bien, maintenant, choississez votre methode de visionnage :");
		button.setText("Visionnage manuel (coup par coup)");
		button2.setText("Affiche la moyenne de resolution sur 100 lancement");

		panel2.add(label);
		panel.add(button);
		panel.add(button2);

		this.add(panel2,BorderLayout.NORTH);
		this.add(panel,BorderLayout.CENTER);
	}
	/**
	 * La onzieme fenetre donne le choix entre un affichage manuel ou un affichage de la moyenne
	 *
	 * @param centFois vrai si le visionnage manuel n'a pas ete choisit, faux sinon
	 */
	public void vision(boolean centFois){
		getContentPane().removeAll();
		getContentPane().revalidate();

		this.setSize(1000,830);

		addKeyListener(keyevent);
		this.requestFocus();

		if (!centFois){
			s.setDimension(dimension);
			s.setCase(cases);
			this.addMouseListener(ql);
		}
		if (centFois){
			moyenne = cfa.centFois(dimension,cases,!alea);
			this.resultat();
		}
		else if (alea && !centFois){
			aa.aleatoire(dimension,cases);
			this.add(s);
			JOptionPane.showMessageDialog(null, " Une derniere chose !\n Pour vous deplacer en mode manuel, utilisez les fleches directionnelles !\n -Droite pour aller a l'etape suivante\n -Gauche pour revenir a l'etape precedente \n\n Enfin, la case avec le point d'interrogation devant thesee represente son prochain mouvement.\n Appuyez sur Quitter pour arreter le programme.",
							"Informations pratiques", JOptionPane.PLAIN_MESSAGE);
		}
		else {
			boolean impossible = ad.determine(dimension,cases);
			this.add(s);
			if (!impossible){
				JOptionPane.showMessageDialog(null, "Ce labyrinthe est impossible à faire !",
	            "Informations pratiques", JOptionPane.PLAIN_MESSAGE);
			}

			JOptionPane.showMessageDialog(null, " Une derniere chose !\n Pour vous deplacer en mode manuel, utilisez les fleches directionnelles !\n -Droite pour aller a l'etape suivante\n -Gauche pour revenir a l'etape precedente \n\n Enfin, la case avec le point d'interrogation devant thesee represente son prochain mouvement.\n Appuyez sur Quitter pour arreter le programme.",
	            "Informations pratiques", JOptionPane.PLAIN_MESSAGE);

		}

	}

	/**
	 * La douzieme fenetre donne la moyenne de coup necessaire pour faire le labyrinthe
	 *
	 */
	public void resultat(){
		getContentPane().removeAll();
		getContentPane().revalidate();
		panel.remove(button2);

		label.setText("L'automate aleatoire a trouve la sortie en (moyenne sur 100 essaies) : "+moyenne+" coups");
		button.setText("Quitter");

		panel.add(label);
		panel.add(button);

		this.add(panel);

	}
}
