/**
 * La classe <code>Main</code> est utilise pour lancer la class Fenetre et tout le programme
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */
import javax.swing.*;
import java.awt.*;
 
public class Main {
    public static void main(String[] args) {
        Fenetre fen = new Fenetre();
        fen.setVisible(true);
    }
}