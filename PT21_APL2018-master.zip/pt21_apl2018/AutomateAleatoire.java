/**
 * La classe <code>AutomateAleatoire</code> est utilisee pour remplir le 
 * tableau evolution des mouvement de l'automate aleatoire
 *  
 * @version 1.0
 * @author Lucca Anthoine & Antoine Papillon
 */


import java.util.Random;

public class AutomateAleatoire{

	private Simulation simulation = null;
	private IsInTab iit = new IsInTab();
	private Random r = new Random();

	/**
   	 * Variable egale au nombre de coup qu'a mis l'automate aleatoire a finir le labyrinthe
   	 */
	private int max;
	/**
   	 * Tableau contenant la position x et y en un temps i
   	 * x etant evolution[i][0]
   	 * y etant evolution[i][1]
   	 */
	private int evolution[][]=new int[100000][2];


	public AutomateAleatoire (Simulation sim){
		this.simulation = sim;
	}

	/**
	 * Remplit le tableau evolution des mouvements de l'algorithme aleatoire
	 *
	 * @param dimension taille du cote du labyrinthe
	 * @param cases labyrinthe
	 */
	public void aleatoire(int dimension,int cases[][]){
		int direction;
		int i,j,sx,sy;
		int tx=0;
		int ty=0;

		for (i=0;i<dimension;i++){
			for (j=0;j<dimension;j++){
				
				if(cases[i][j]==3){
					sx=i;
					sy=j;
				}else if(cases[i][j]==2){
					tx=i;
					ty=j;
				}
			}
		}
		evolution[0][0]=tx;
		evolution[0][1]=ty;
		boolean arrivee = false;

		for( i=0 ; !arrivee && i<100000; ){
			tx=evolution[i][0];
			ty=evolution[i][1];
		
			direction = r.nextInt(4);

			if (direction == 0){
				tx--;
			}else if(direction == 1){
				ty--;
			}else if(direction == 2){
				tx++;
			}else if(direction == 3){
				ty++;
			}
			if (tx>=0 && tx<dimension && ty>=0 && ty<dimension){
				if (cases[tx][ty]==0 || cases[tx][ty]==2){
					evolution[i+1][0]=tx;
					evolution[i+1][1]=ty;
					i++;
				}else if (cases[tx][ty]==3){
					arrivee=true;
					evolution[i+1][0]=tx;
					evolution[i+1][1]=ty;
				}
			}
		}
		max = i+1;
		simulation.setEvolution(evolution);
		simulation.setMax(max);
	}
	/**
  	 * Renvoie la variable egale au nombre de coup qu'a mis l'automate aleatoire a finir le labyrinthe.
  	 *
   	 * @return le nombre de coup mis par l'automate pour faire le labyrinthe
   	 */
	public int getMax(){
		return max;
	}
}