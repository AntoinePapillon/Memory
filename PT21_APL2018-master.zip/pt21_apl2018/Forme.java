/**
 * La classe <code>Forme</code> est utilise pour afficher le labyrinthe et permettre sa modification jusqu'a
 * la confirmation du choix
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */

import javax.swing.JComponent;
import java.awt.*;
import java.util.Random;

public class Forme extends JComponent {

	private Image sortie = Toolkit.getDefaultToolkit().getImage("./img/mino.png");
	private Image thesee = Toolkit.getDefaultToolkit().getImage("./img/index.png");
	private Image valide = Toolkit.getDefaultToolkit().getImage("./img/validation.png");
	private Image mur = Toolkit.getDefaultToolkit().getImage("./img/mur.png");

	private int dimension=1;
	private int taille_cases=800/dimension;
	private int taille_thesee,taille_sortie;
	private int[][] cases = null;
	private int i,j;
	private int tx;
	private int ty=0;
	private boolean nbrT = false;
	private int sx,sy;
	private boolean nbrS = false;
	private int jaune=1;
	

	private Fenetre f = null;

	public Forme(Fenetre f){
		this.f=f;
	}

	
	/**
	 * Affiche l'etat de chaque case du labyrinthe
	 *
	 * @param pinceau Graphics
	 */
	@Override
	public void paintComponent(Graphics pinceau) {

		Graphics secondPinceau = pinceau.create();
		
		for (i=0;i<dimension;i++){
			for (j=0;j<dimension;j++){
				secondPinceau.setColor(Color.black);
				secondPinceau.fillRect(i*taille_cases,j*taille_cases,taille_cases,taille_cases);

				if(cases[i][j]==0){
					secondPinceau.setColor(Color.white);
					secondPinceau.fillRect(i*taille_cases+1,j*taille_cases+1,taille_cases-2,taille_cases-2);
				}else if (cases[i][j]==2){
					secondPinceau.drawImage(thesee, i*taille_cases+1,j*taille_cases+1,taille_cases-2,taille_cases-2, this);
				}else if (cases[i][j]==3){
					secondPinceau.drawImage(sortie, i*taille_cases+1,j*taille_cases+1,taille_cases-2,taille_cases-2, this);
				}
			}
		}
		secondPinceau.drawImage(valide, 810,630,160,160, this);
		if(nbrT == false){
			secondPinceau.drawImage(thesee, this.tx+10, this.ty+10,taille_thesee,taille_thesee, this);
		}if(nbrS==false){
			secondPinceau.drawImage(sortie, this.sx+10, this.sy+10,taille_sortie,taille_sortie, this);
		}
		
  	}

  	/**
	 * Permet de creer un base de labyrinthe pour l'utilisateur
	 *
	 * @param d dimension du labyrinthe
	 * @param b si vrai, le tableau est vide, si faux il est rempli aleatoirement
	 */
  	public void creationLab(int d,boolean b){
  		Random r = new Random();
  		this.dimension = d;
  		taille_cases=800/dimension;
  		taille_thesee=160;
  		taille_sortie=160;

  		tx=800;
  		sx=800;
  		sy=160;
  		this.cases=new int[dimension][dimension];
  		
	  	for (int i=0;i<dimension;i++){
			for (int j=0;j<dimension;j++){
				if (b){
					this.cases[i][j]=0;
				}else {
					this.cases[i][j]=r.nextInt(2);
				}
			}
		}
  	}

  	/**
	 * Permet de determiner quoi faire en fonction de la position du clic
	 *
	 * @param x position en x du clic
	 * @param y position en y du clic
	 * @param b determine si la sortie ou thesee sont actuellement suivis (egal a 0,1 ou 2)
	 * @return si la sortie ou thesee doivent etre suivis (egal a 0,1 ou 2)
	 */
  	public int clicked(int x, int y,int b){

  		i=x/taille_cases;
  		j=y/taille_cases;

  		if( x>=810 && x<=970 && y>=10 && y<=170 && b!=2 ){
  			if (nbrT == false){
  				return 1;
  			}
  			else {
  				return 0;
  			}
  		}else if ( x>=810 && x<=970 && y>=170 && y<=340 && b!=1){
  			if ( nbrS==false ){
  				return 2;
  			}else {
  				return 0;
  			}
  		}
  		else if ( b==1 && !nbrT && i<dimension && j<dimension){
  			if(cases[i][j]==3){
  				nbrS=false;
  				sx = 800;
	  			sy=160;
  			}
  			cases[i][j]=2;
	  		nbrT=true;
	  		taille_thesee=160;
	  		return 0;
	  	}else if ( b==1 && !nbrT && i>=dimension || j>=dimension){
	  		return 1;
	  	}
	  	else if (b==2 && !nbrS && i<dimension && j<dimension){
	  		if(cases[i][j]==2){
  				nbrT=false;
  				tx = 800;
	  			ty=0;
  			}

	  		cases[i][j]=3;
	  		nbrS=true;
	  		taille_sortie = 160;
	  		return 0;
	  	}else if ( b==2 && !nbrS && i>=dimension || j>=dimension){
	  		return 2;
	  	}
  		else if(i<dimension && j<dimension){
	  		if (cases[i][j]==0){
	  			cases[i][j]=1;
	  		}else if (cases[i][j]==2){
	  			cases[i][j]=0;
	  			nbrT = false;
	  			taille_thesee=160;
	  			tx = 800;
	  			ty=0;
	  		}else if (cases[i][j]==3){
	  			cases[i][j]=0;
	  			nbrS = false;
	  			taille_sortie=160;
	  			sx = 800;
	  			sy=160;
	  		}
	  		else {
	  			cases[i][j]=0;
	  		}
	  		return 0;
	  	}else if (x>=810 && x<=970 && y>=650 && y<=790){
	  		if (nbrS == false || nbrT == false){
	  		}else{
	  			f.sauvegarde(cases);
	  		}
	  		return 0;
	  	}else{
	  		return 0;
	  	}
  	}

  	/**
	 * Permet que thesee suive la souris
	 *
	 * @param x position en x du clic
	 * @param y position en y du clic
	 */
  	public void followT(int x, int y){

  		tx=x-(taille_cases/2);
  		ty=y-(taille_cases/2);

  	}
  	/**
	 * Permet que la sortie suive la souris
	 *
	 * @param x position en x du clic
	 * @param y position en y du clic
	 */
  	public void followS(int x, int y){

  		sx=x-(taille_cases/2);
  		sy=y-(taille_cases/2);

  	}
  	/**
	 * Met la taille de la sortie a une taille egale a celle d'une case
	 *
	 */
  	public void setTailleSortie(){
  		taille_sortie=taille_cases;
  	}
  	/**
	 * Met la taille de la sortie a une taille egale a celle d'une case
	 *
	 */
  	public void setTailleThesee(){
  		taille_thesee=taille_cases;
  	}
}