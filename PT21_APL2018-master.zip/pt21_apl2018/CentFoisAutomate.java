/**
 * La classe <code>CentFoisAutomate</code> est utilise pour lancer cent fois l'automate choisi
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */

public class CentFoisAutomate{
	private AutomateAleatoire aa = null;
	private AutomateDetermine ad = null;

	public CentFoisAutomate(AutomateAleatoire aleatoire, AutomateDetermine determine){
		this.aa = aleatoire;
		this.ad = determine;
	}
	/**
	 * Execute centFois un algorithme choisi precedemment
	 * Renvoie le nombre de coups qui ont ete necessaire aux l'algorithme pour faire le labyrinthe
	 * @param dimension taille du cote du labyrinthe
	 * @param cases labyrinthe
	 * @param deter si faux lance automate aleatoire, determine sinon
	 * @return le nombre moyen de coups necessaire en moyenne pour l'automate choisi pour trouver la sortie
	 */
	public int centFois(int dimension,int[][] cases,boolean deter){
		int moyenne=0,i;
		for (i=0;i<100;i++){
			if (deter == false){
				aa.aleatoire(dimension,cases);
				moyenne = moyenne + aa.getMax();
			}
			else if (deter == true){
				ad.determine(dimension,cases);
				moyenne = moyenne + ad.getMax();
			}
		}
		return moyenne/100;
	}
}