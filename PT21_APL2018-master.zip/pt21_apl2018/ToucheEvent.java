/**
 * La classe <code>Fenetre</code> est utilise pour afficher les fenetres qui se succedent
 * jusqu'a mener a l'algorithme, il contient : 
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class ToucheEvent implements KeyListener {
	private Simulation sim = null; 

	public ToucheEvent(Simulation sim){
		this.sim=sim;
	}
	
	/**
	 * Permet de determiner quoi faire en cas d'activation de la touche directionnelle droite ou gauche
	 *
	 * @param e KeyEvent
	 */
	public void keyPressed(KeyEvent e){

		if(e.getKeyCode()==37)	{
			sim.enArriere();
			sim.repaint();
		}else if (e.getKeyCode()==39){
			sim.enAvant();
			sim.repaint();
		}
		
	}

	public void keyTyped(KeyEvent e){}
	public void keyReleased(KeyEvent e){}
}