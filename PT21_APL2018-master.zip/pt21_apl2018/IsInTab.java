/**
 * La classe <code>IsInTab</code> est utilise pour determiner si une valeur est dans un tableau tout deux donne en argument
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */
public class IsInTab {
	
	/**
	 * Verifie si la valeur en argument est dans le tableau en argument
	 * @param c tableau
	 * @param val valeur a chercher
	 * @return un booleen qui indique si la valeur est dans le tableau en argument ou pas
	 */
	public boolean existeDansTableau(int[] c, int val){
		for(int i=0 ; i<c.length;i++){
			if(val==c[i]){
			   	return false;
			}
		}
		return true;
	}
}

