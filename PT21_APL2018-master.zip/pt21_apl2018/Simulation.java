/**
 * La classe <code>Simulation</code> est utilisee pour afficher les actions des algorithmes
 * dans le labyrinthe.
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */
import javax.swing.JComponent;
import java.awt.*;
import java.util.Random;

public class Simulation extends JComponent {
	
	private Image meurtre = Toolkit.getDefaultToolkit().getImage("./img/meurtre.png");
	private Image sortie = Toolkit.getDefaultToolkit().getImage("./img/mino.png");
	private Image thesee = Toolkit.getDefaultToolkit().getImage("./img/index.png");
	private Image quit = Toolkit.getDefaultToolkit().getImage("./img/quit.png");
	private Image next = Toolkit.getDefaultToolkit().getImage("./img/next.png");

 	/**
  	 * Tableau contenant le labyrinthe
  	 * 1 pour un mur
  	 * 0 pour une case vide
  	 * 3 pour la sortie
  	 * 2 pour Thesee
  	 */
	private int cases[][]=null;
	/**
	 * Tableau contenant l'evolution de l'algorithme choisit
	 */
	private int evolution[][]=null;

	private int i,j,dimension;
	/**
	 * Variable indiquant notre position dans evolution, et qui nous permet de naviguer dans celui ci.
	 */
	private int compte = 0;
	/**
   	 * Variable egale au nombre de coup qu'a mis l'automate aleatoire a finir le labyrinthe
   	 */
	private int max;
	private int taille_cases;

	public Simulation(){
	}

	/**
	 * Affiche le labyrinthe, la position de thesee et celle de la sortie
	 */
	@Override
	public void paintComponent(Graphics pinceau) {
		
		Graphics secondPinceau = pinceau.create();

		String etapes = "Etape : "+compte;

		for (i=0;i<dimension;i++){
			for (j=0;j<dimension;j++){
				secondPinceau.setColor(Color.black);
				secondPinceau.fillRect(i*taille_cases,j*taille_cases,taille_cases,taille_cases);
				if(cases[i][j]==0 || cases[i][j]==2 ){
					secondPinceau.setColor(Color.WHITE);
					secondPinceau.fillRect(i*taille_cases+2,j*taille_cases+2,taille_cases-2,taille_cases-2);
				}else if (cases[i][j]==3){//sortie
					secondPinceau.drawImage(sortie, i*taille_cases+2,j*taille_cases+2,taille_cases-2,taille_cases-2, this);
				}
			}
		}
		
		if (max == compte){
			secondPinceau.drawImage(meurtre,evolution[compte][0]*taille_cases+2,evolution[compte][1]*taille_cases+2,taille_cases-2,taille_cases-2, this);
		}else {
			secondPinceau.drawImage(thesee,evolution[compte][0]*taille_cases+2,evolution[compte][1]*taille_cases+2,taille_cases-2,taille_cases-2, this);
			secondPinceau.drawImage(next,evolution[compte+1][0]*taille_cases+2,evolution[compte+1][1]*taille_cases+2,taille_cases-2,taille_cases-2, this);
		}
		
		secondPinceau.setColor(Color.black);
		secondPinceau.drawString(etapes,810,50);
		secondPinceau.drawImage(quit, 810,630,160,160, this);
	}
	/**
	 * Regle le tableau evolution
	 */
	public void setEvolution(int[][] evolution){
		this.evolution = evolution;
	}
	/**
	 * Regle max
	 */
	public void setMax(int maximum){
		this.max = maximum;
	}
	/**
	 * Regle le dimension
	 * determine taille_cases
	 */
	public void setDimension(int dim){
		this.dimension=dim;
		taille_cases=800/dimension;
	}
	/**
	 * Regle le tableau cases
	 */
	public void setCase(int[][] cases){
		this.cases=cases;
	}
	/**
	 * Fait avancer l'affichage de Thesee d'une action
	 */
	public void enAvant(){
		compte = compte +1;
		if (compte >= max){
			compte = max;
		}
	}
	/**
	 * Fait reculer l'affichage de Thesee d'une action
	 */
	public void enArriere(){
		compte = compte - 1;
		if (compte < 0){
			compte = 0;
		}
	}
}