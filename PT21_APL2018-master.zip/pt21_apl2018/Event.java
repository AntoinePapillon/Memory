/**
 * La classe <code>Event</code> est utilise pour gerer les mouvement
 * de souris et les clics sur le fenetre generer par la classe fenetre.
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */


import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Event implements MouseListener, MouseMotionListener {

	private Fenetre v=null;
	private Forme f=null;
	private SuperCoding s = null;
	private Simulation sim = null;

	private int motion=0;

	public Event(Fenetre v, Forme f, Simulation sim,SuperCoding s){

		this.v=v;
		this.f=f;
		this.sim=sim;
		this.s=s;

	}

	/**
	 * Envoie les coordonnees des clics a la classe forme
	 * pour qu'ils soient traite.
	 *
	 * @param e MouseEvent
	 */
	public void mouseClicked(MouseEvent e){

		motion = this.f.clicked((e.getX()),(e.getY()-30),motion);
		this.f.repaint();
		if(motion == 1) {
			this.f.setTailleThesee();
		}if (motion == 2){
			this.f.setTailleSortie();
		}

	}

	/**
	 * Permet de faire en sorte que la sortie ou thesee suive la souris dans ces mouvements.
	 *
	 * @param e MouseEvent
	 */
	public void mouseMoved(MouseEvent e){

		if(motion == 1){
			this.f.followT(e.getX(),(e.getY()-30));
			this.f.repaint();
		}else if (motion == 2){
			this.f.followS(e.getX(),(e.getY()-30));
			this.f.repaint();
		}
		
	}

	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseDragged(MouseEvent e){}

}