/**
 * La classe <code>QuitListener</code> est utilise pour detecter si l'utilisateur a clique sur le bouton pour quitter
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class QuitListener implements MouseListener {

	public QuitListener(){
	}
	/**
	 * Permet de determiner les coordonnees du clic et de fermer la fenetre si les conditions sont remplis
	 *
	 * @param e MouseEvent
	 */
	public void mouseClicked(MouseEvent e){
		if (e.getX()-30>810 && e.getX()-30<970 && e.getY()-30>630 && e.getY()-30<790){
			System.exit(0);
		}
	}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}