/**
 * La classe <code>ButtonListener</code> est utilise pour gerer les actions
 * a realiser en fonction du bouton clique
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class ButtonListener implements ActionListener {

	private Fenetre v=null;

	public ButtonListener(Fenetre v){
		this.v=v;
	}

	/**
	 * Lance une nouvelle fenetre en fonction du bouton active
	 *
	 * @param e ActionEvent
	 */
	public void actionPerformed(ActionEvent e){

		JButton button = (JButton) e.getSource();
		
		if(button.getText().equals("Creer un Labyrinthe")){
			this.v.taille();
		}
		else if(button.getText().equals("Selectionner un Labyrinthe deja existant")){
			this.v.selection();
		}
		else if (button.getText().equals("OK")){
			this.v.choixConstruction();
		}
		else if (button.getText().equals("Labyrinthe vide")){
			this.v.creation(true);
		}
		else if (button.getText().equals("Labyrinthe Prerempli")){
			this.v.creation(false);
		}
		else if (button.getText().equals("Oui")){
			this.v.nomSauvegarde();
		}
		else if (button.getText().equals("Non")){
			this.v.automate();
		}
		else if (button.getText().equals("Passez a la simulation")){
			this.v.automate();
		}
		else if (button.getText().equals("Automates Aleatoire")){
			this.v.visionnage(true);
		}
		else if (button.getText().equals("Automate Determine")){
			this.v.visionnage(false);
		}
		else if (button.getText().equals("Affiche la moyenne de resolution sur 100 lancement")){
			this.v.vision(true);
		}
		else if (button.getText().equals("Visionnage manuel (coup par coup)")){
			this.v.vision(false);
		}
		else if (button.getText().equals("Valider")){
			this.v.lancement();
		}
		else if (button.getText().equals("Quitter")){
			System.exit(0);
		}

	}
}