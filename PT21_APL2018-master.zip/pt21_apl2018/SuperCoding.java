/**
 * La classe <code>SuperCoding</code> est utilisee pour sauvegarder le labyrinthe creer ou lire un labyrinthe precedemment sauvegarder
 *
 * @version 1.0
 * @author Antoine Papillon & Lucca Anthoine
 */

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;

public class SuperCoding {
	private int[][] cases = null;
	private byte dimension;

	private byte tampon=0;
	private byte tx,ty,sx,sy,puissance;
	private byte bits;
	private int compte = 0;
	private byte j,i;

	public SuperCoding(){

	}

	/**
	 * Permet d'ecrire le labyrinthe en argument dans un fichier .lab
	 *
	 * @param dimension la taille du labyrinthe a sauvegarder
	 * @param cases le labyrinthe a sauvegarder
	 * @param nomSave le nom du labyrinthe a sauvegarder
	 */
	public void sauvegarde(int dimension, int[][] cases,String nomSave){
		this.cases = cases;
		this.dimension =(byte) dimension;
		
		byte[] donnee=new byte[(dimension*dimension/8)+1];
		
		for (i=0;i<dimension;i++){
			for (j=0;j<dimension;j++){
				if(cases[i][j]==2){
					tx = i;
					ty = j;
				}
				else if (cases[i][j]==3){
					sx = i;
					sy = j;
				}
			}
		}

		puissance = 7;
		for (i=0;i<dimension;i++){
			for (j=0;j<dimension;j++){

				if ((i*dimension+j)%8 == 0 && i+j!=0 ){
					donnee[compte]=tampon;
					compte ++;
					puissance=7;
					tampon = 0;
				}

				if (cases[i][j]==0 || cases[i][j]==1){
					bits =(byte) cases[i][j];

				}else {
					bits = 0;
				}
				bits = (byte) (bits * Math.pow(2,puissance));

				tampon = (byte) (tampon+bits);
				puissance --;

			}
		}
		donnee[compte]=tampon;

		try{
			FileOutputStream saveFile = new FileOutputStream("./Sauvegarde/"+nomSave+".lab");
			DataOutputStream saveWriter = new DataOutputStream(saveFile);
			try{
				saveWriter.write(dimension);
				saveWriter.write(ty);
				saveWriter.write(tx);
				saveWriter.write(sy);
				saveWriter.write(sx);
				for (i=0;i<compte+1;i++){
					saveWriter.write(donnee[i]);
				}
			}catch (IOException e5) {
				System.err.println("read error or write error");
			}
			saveWriter.close();
		}catch(IOException e){
			System.err.println("IOException");
		}
	}
	/**
	 * Permet de lire un labyrinthe
	 *
	 * @param fileName le nom du labyrinthe a lire
	 */
	public int[][] lecteur(String fileName){
		try{
			FileInputStream filereader = new FileInputStream("./Sauvegarde/"+fileName);
			DataInputStream saveReader = new DataInputStream(filereader);
			try {
				dimension = saveReader.readByte();

				ty = saveReader.readByte();
				tx = saveReader.readByte();
				sy = saveReader.readByte();
				sx = saveReader.readByte();

				cases = new int[dimension][dimension];

				for (i=0;i<dimension;i++){
					for (j=0;j<dimension;j++){

						if ((i*dimension+j)%8==0){
							tampon = saveReader.readByte();
						}

						if (( tampon&(byte)Math.pow(2,7-(i*dimension+j)%8))  != 0){
							cases[i][j]=1;
						}else{
							cases[i][j]=0;
						}
					}
				}
				cases[tx][ty]=2;
				cases[sx][sy]=3;
			}catch (IOException e5) {
				System.err.println("read error or write error");
			}
			saveReader.close();
		}catch(IOException e){
			System.err.println("IOException");
		}
		return cases;
	}
	/**
	 * Permet de recuperer la taille du labyrinthe
	 * @return la taille du labyrinthe
	 */
	public int getDimension(){
		return (int) dimension;
	}

}
