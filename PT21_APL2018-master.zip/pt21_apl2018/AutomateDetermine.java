/**
 * La classe <code>AutomateDetermine</code> est utilisee pour remplir le 
 * tableau evolution des mouvement de l'automate determine
 *  
 * @version 1.0
 * @author Lucca Anthoine & Antoine Papillon
 */

import java.util.Random;

public class AutomateDetermine{
	private Simulation simulation = null;
	private IsInTab iit = new IsInTab();
	private Fenetre f = null;
	private Random r = new Random();

	/**
   	 * Variable egale au nombre de coup qu'a mis l'automate determine a finir le labyrinthe
   	 */
	private int max;
	/**
   	 * Tableau contenant la position x et y en un temps i
   	 * x etant evolution[i][0]
   	 * y etant evolution[i][1]
   	 */
	private int evolution[][]=new int[100000][2];

	public AutomateDetermine(Simulation sim,Fenetre f){
		this.simulation = sim;
		this.f = f;
	}

	/**
	 * Remplit le tableau evolution des mouvements de l'algorithme determine
	 * Renvoie si le labyrinthe est faisable ou pas
	 * (false = infaisable)
	 *
	 * @param dimension taille du cote du labyrinthe
	 * @param cases labyrinthe
	 * @return si le labyrinthe est faisable ou pas
	 */
	public boolean determine(int dimension,int[][] cases){
		int i,j,sx,sy;
		int tx=0;
		int ty=0;

		for (i=0;i<dimension;i++){
			for (j=0;j<dimension;j++){
				if(cases[i][j]==2){
					tx=i;
					ty=j;
				}
			}
		}
		evolution[0][0]=tx;
		evolution[0][1]=ty;

		int trajet[] = new int[dimension*dimension];
		int degree[] = new int[dimension*dimension];
		int direction,x,y;
		boolean arrivee = false;

		for (i=0 ; i<(dimension*dimension) ; i++){
			trajet[i]=-1;
		}
		trajet[0]=tx+ty*dimension;

		for (i=0,j=0;!arrivee && i>=0;j++){

			x=trajet[i]%dimension;
			y=trajet[i]/dimension;
			direction = degree[i];

			evolution[j][0]=x;
			evolution[j][1]=y;

			if (direction==0){
				if ((y-1)>=0 && (y-1)<dimension){
					if (cases[x][(y-1)]!=1 && iit.existeDansTableau(trajet,x+(y-1)*dimension)){
						degree[i]=(direction+1);
						i++;
						trajet[i]=x+(y-1)*dimension;
						degree[i]=0;
					}else{
						direction++;
					}
				}else {
					direction++;
				}
			}if (direction==1){
				if ((x+1)>=0 && (x+1)<dimension){
					if (cases[(x+1)][y]!=1 && iit.existeDansTableau(trajet,(x+1)+y*dimension)){
						degree[i]=(direction+1);
						i++;
						trajet[i]=(x+1)+y*dimension;
						degree[i]=0;
					}else{
						direction++;
					}
				}else {
					direction++;
				}
			}if (direction==2){
				if ((y+1)>=0 && (y+1)<dimension){
					if(cases[x][y+1]!=1 && iit.existeDansTableau(trajet,x+(y+1)*dimension)){
						degree[i]=(direction+1);
						i++;
						trajet[i]=x+(y+1)*dimension;
						degree[i]=0;
					}else{
						direction++;
					}
				}else {
					direction++;
				}
			}if ( direction==3 ){
				if ( (x-1)>=0 && (x-1)<dimension){
					if (cases[x-1][y]!=1 && iit.existeDansTableau(trajet,(x-1)+y*dimension) ){
						degree[i]=(direction+1);
						i++;
						trajet[i]=(x-1)+y*dimension;
						degree[i]=0;
					}else{
						direction++;
					}
				}else {
					direction++;
				}
			}if (direction == 4){
				i--;
			}

			if(cases[x][y]==3){
				arrivee = true;
			}
		}
		
		max =j-1;
		simulation.setEvolution(evolution);
		simulation.setMax(max);
		if (i==-1){
			return false;
		}else {
			return true;
		}
	}

	/**
  	 * Renvoie la variable egale au nombre de coup qu'a mis l'automate determine a finir le labyrinthe.
  	 *
   	 * @return le nombre de coup mis par l'automate pour faire le labyrinthe
   	 */
	public int getMax(){
		return max;
	}
}