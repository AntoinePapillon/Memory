#include <graph.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>


void Triche(int FenetreX, int FenetreY);                                     /*Il s'agit de la fonction permettant le mode triche*/

void AFFICHAGE(int *tab, int e, int hauteur, int largeur, int NombreCartes);    /*Il s'agit de la fonction permettant d'afficher nos cartes*/

void Cadrillage(int FenetreX, int FenetreY);                                    /*Il s'agit de la fonction nous permettant de creer la fenetre adaptée*/







int jeu(int Difficulte) {
#define NBR_TOTAL NombreCartes*NombreCartes

int NombreCartes;
int FenetreX,FenetreY;

if (Difficulte == 1){           /*Mode Facile, on a besoin d'une petite fenetre*/
  NombreCartes = 4;
  FenetreX = 585;
  FenetreY = 585;
}else if (Difficulte == 2) {    /*Mode Normal, on a besoin d'une fenetre moyenne*/
  NombreCartes = 6;
  FenetreX = 875;
  FenetreY = 875;
}else if (Difficulte == 3) {    /*Mode Diffcile, on a besoin d'une grande fenetre*/
  NombreCartes = 8;
  FenetreX = 1105;    /* Comme il s'agit d'une grande fenetre de 1105*1105 mais que*/
  FenetreY = 1105;    /*la plupart des ordinateurs modernes sont en 1080*1920 il se peut que on dépasse un peu en bas*/
}

  Cadrillage(FenetreX, FenetreY);   /*On prend les coordonnée en fonction de la difficulté */


  srand(time(NULL));
  int Cache, pos_cache;
  int hauteur, largeur, i, error;   /* la variables "i" nous sert seulement à faire des incrementation en tout genre*/


  ChoisirEcran(1);
  ChargerImageFond("./image/Fondjeu.png");
  ChoisirEcran(0);


  int tab[NBR_TOTAL];
  int c;                /* la variable "c" sert juste à remplir notre tableau de base pour ensuite le melanger*/
  int valeur=1;
  int random_ligne, temp1;

/* On parcours le tableau */

for (c = 0; c < NBR_TOTAL;c+=2) { /* On créer un tableau de la forme "[1,1,2,2,3,3,.....]" */
  tab[c]=valeur;
  tab[c+1]=valeur;
  valeur++;
}
for (c = 0; c < NBR_TOTAL; c += 1) {
    /* On échange la valeur de 2 cases aléatoire de façon aléatoire */
    random_ligne = c + rand() % (NBR_TOTAL - c);
    temp1 = tab[c];
    tab[c] = tab[random_ligne];
    tab[random_ligne] = temp1;
}


  ChoisirEcran(1);                            /*Ici on rempli notre écran que l'on affichera pour le mode triche*/
  for (i = 0; i < NBR_TOTAL; i++) {

    largeur = 1 + ((i / NombreCartes) * 2);   /*Ce calcul nous permet d'afficher les cartes à la bonne position*/
    hauteur = 1 + (2 * (i % NombreCartes));
    char Image[NBR_TOTAL];
    sprintf(Image, "image/M%d.png", tab[i]);
    ChargerImage(Image, largeur * 65, hauteur * 65, 0, 0, 65, 65);
  }
  ChoisirEcran(0);


  /*CACHE*/

  for (pos_cache = 0; pos_cache < NBR_TOTAL; pos_cache++) {     /*On va ici afficher une image qui va servir à cacher nos cartes*/
    largeur = 1 + ((pos_cache / NombreCartes) * 2);             /*Ce calcul nous permet d'afficher les cartes à la bonne position*/
    hauteur = 1 + (2 * (pos_cache % NombreCartes));

    ChargerImage("image/Cache.png", hauteur * 65, largeur * 65, 0, 0, 65, 65);
  }

  /*Le Clique */

  int e, victoire = 0;          /*e est une variable d'incrementation et victoire celle qui va compter chaque fois qu'on réussi une paire*/
  int tabEtat[NBR_TOTAL];
  int sauvge, sauvgh, sauvgl;   /*Il s'agit de sauvegarde de la valeur de e,hauteur et largeur*/
  int tentative;
  for (i = 0; i < NBR_TOTAL; i++) {
    tabEtat[i] = 0;                     /*On remplis le tableau de 0 pour pouvoir effectuer une verification par la suite*/
  }


  #define CYCLE 1000000L
  int secondes = 0;
  unsigned long suivant = 0;
  char timer[200];
  ChoisirCurseur(2);

  while (True) {

    for (tentative = 0; tentative < 2;) {
      Triche(FenetreX,FenetreY);
      if(Microsecondes() > suivant && victoire != (NBR_TOTAL/2)){       /*Ici on affiche le temps écoulé*/
        suivant = Microsecondes()+CYCLE;
        secondes ++;
        sprintf(timer, " Temps : %4d s",secondes);
        CopierZone(1, 0, 0, 0,585,40, 0, 0);

        EcrireTexte(30,30,timer,2);
      }

      if (SourisCliquee()) {

        for (e = 0; e < NBR_TOTAL; e++) {
          largeur = 1 + ((e / NombreCartes) * 2);
          hauteur = 1 + (2 * (e % NombreCartes));

          if ((_X >= largeur * 65) && (_X <= (largeur + 1) * 65) &&
              (_Y >= hauteur * 65) && (_Y <= (hauteur + 1) * 65)) {

            if (tabEtat[e] == 1) {
              printf("image deja tournée \n");
            } else {

              AFFICHAGE(tab, e, hauteur, largeur, NombreCartes);

              if (tentative == 0) {           /*On effectue une sauvegarde de nos coordonnée pour pouvoir les comparer par la suite*/
                sauvgh = hauteur;
                sauvgl = largeur;
                sauvge = e;
                tabEtat[e] = 1;

              }
              if (tentative == 1) {
                if (tab[e] == tab[sauvge]) {
                  tabEtat[e] = 1;
                  victoire = victoire + 1;
                  if (victoire == (NBR_TOTAL/2)) {
                    FermerGraphique();
                    Cadrillage(585,585);
                    ChargerImageFond("./image/Win.png");

                  }

                } else {
                  usleep(1000000);                                              /*le délai d'une seconde avant de retourner les cartes*/
                  ChargerImage("image/Cache.png", largeur * 65, hauteur * 65,
                               0, 0, 65, 65);
                  ChargerImage("image/Cache.png", sauvgl * 65, sauvgh * 65, 0,
                               0, 65, 65);
                  tabEtat[sauvge] = 0;
                }
              }
              tentative = tentative + 1;

            }
          }
        }

   
      }
    }
  }

  Touche();
  FermerGraphique();

  return EXIT_SUCCESS;
}

/*____________________________________________________________________________*/
                /* Ici se situe toutes les fonctions appelées*/

void Triche(int FenetreX, int FenetreY) {          /*La fonction de triche*/
  int touche;
  int poubelle;
  if (ToucheEnAttente()) {
    touche = Touche();
    if (touche == XK_t) {                             /*On l'utilise en appuyant sur "t"*/
      CopierZone(0, 2, 0, 40, FenetreX, FenetreY, 0, 40);
      CopierZone(1, 0, 0, 40, FenetreX, FenetreY, 0, 40);

      ToucheEnAttente();
      touche = Touche();
      while (SourisCliquee()) {
        /* nettoyage du tampon du clique */
        poubelle = _X;
        poubelle = _Y;
      }
      while (touche != XK_t) {
        printf("La touche n'est pas prise en charge\n");
        ToucheEnAttente();
        touche = Touche();
      }
      CopierZone(2, 0, 0, 40, FenetreX, FenetreY, 0, 40);
    }
  }
}



void AFFICHAGE(int *tab, int e, int hauteur, int largeur , int NombreCartes) {      /*La fonction d'affichage de nos cartes*/
  char Image[NBR_TOTAL];
  sprintf(Image, "image/M%d.png", tab[e]);
  ChargerImage(Image, largeur * 65, hauteur * 65, 0, 0, 65, 65);

}



void Cadrillage(int FenetreX, int FenetreY) {                             /*La fonction créant notre fenetre*/
  InitialiserGraphique();
  CreerFenetre(585, 300, FenetreX, FenetreY);
  ChargerImageFond("image/Fondjeu.png");
}
