#ifndef JOUER_H
#define JOUER_H


int jeu(int Difficulte);
void Cadrillage(int FenetreX, int FenetreY);
void AFFICHAGE(int *tab, int e, int hauteur, int largeur, int NombreCartes);
void Triche(int FenetreX, int FenetreY);

#endif /* JOUER_H */
