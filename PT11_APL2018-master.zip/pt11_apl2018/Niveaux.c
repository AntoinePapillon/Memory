#include <graph.h>
#include <stdio.h>
#include <stdlib.h>
#include "Jouer.h"


int Niveaux(void) {
  InitialiserGraphique();
  CreerFenetre(585, 300, 585, 585);
  ChargerImageFond("image/MBackground2.png");
  int x, y;
  ChoisirCurseur(2);
  SourisPosition();
  x = _X;
  y = _Y;
  while (True) {
    if(SourisCliquee()){
      if ((_X >= 267) && (_X <= 341) && (_Y >= 210) && (_Y <= 233)) {       /* Ici, selon là où est placé le clique on envoie la valeur 1,2 ou 3*/
        FermerGraphique();                                                  /* Cette valeur va permettre de définir la difficultée du jeu*/
        jeu(1);
      }
      if ((_X >= 266) && (_X <= 339) && (_Y >= 269) && (_Y <= 293)) {
        FermerGraphique();
        jeu(2);
      }
      if ((_X >= 268) && (_X <= 367) && (_Y >= 331) && (_Y <= 353)) {
        FermerGraphique();
        jeu(3);
      }
    }
  }

  Touche();
  return EXIT_SUCCESS;
}
