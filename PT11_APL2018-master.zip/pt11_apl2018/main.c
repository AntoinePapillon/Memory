#include "Niveaux.h"
#include <graph.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {                            /*Il s'agit de la fonction qui s'occupera du menu*/

  InitialiserGraphique();
  CreerFenetre(585, 300, 585, 585);                           /*On initialise la fenetre au centre de l'ecran*/
  ChargerImageFond("image/MBackground.png");
  int x, y;
  ChoisirCurseur(2);
  SourisPosition();
  x = _X;
  y = _Y;
  while (True) {
    if (SourisCliquee()) {
      if ((_X >= 235) && (_X <= 343) && (_Y >= 215) && (_Y <= 243)) {       /*Si le clique est situé dans ce perimetre du clique, alors on lance la fonction des niveaux*/
        FermerGraphique();
        Niveaux();
      }
      if ((_X >= 233) && (_X <= 361) && (_Y >= 304) && (_Y <= 334)) {       /*Si le clique est situé dans ce perimetre du clique, alors on quitte le jeu*/
        printf("Au revoir !\n");
        exit(1);
      }
      if ((_X >= 41) && (_X <= 66) && (_Y >= 29) && (_Y <= 66)) {          /*Si le clique est situé dans ce perimetre du clique, alors on lance la fonction de l'aide*/
        ChargerImageFond("./image/Aide.png");

      }
    }
  }

  Touche();
  return EXIT_SUCCESS;
}
