#ifndef _IMAGE_H
#define _IMAGE_H
int _chargerimage(char *f, int *x,int *y,Pixmap  * p , Pixmap * pmask,Display *display,GC gc,int screen);
#endif

