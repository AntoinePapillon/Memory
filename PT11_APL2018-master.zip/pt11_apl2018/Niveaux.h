#ifndef NIVEAUX_H
#define NIVEAUX_H

int Niveaux(void);

#endif /* NIVEAUX_H */
